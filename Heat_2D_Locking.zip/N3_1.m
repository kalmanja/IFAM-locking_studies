function N_3 = N3_1(xi,eta)

N_3 = 0.25*(1+xi)*(1+eta);

end