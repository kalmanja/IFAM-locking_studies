function kloc = stiffnessmatrix(X,Y,ngauss,thk,kxx,kyy)

D = [kxx 0; 0 kyy];

if ngauss == 4
    kloc = zeros(4,4);
    for i = 1:ngauss
        if i == 1
            [J,Jinv,jac,B] = jacobian_calc(X,Y,-1/sqrt(3),-1/sqrt(3));
        elseif i ==2
            [J,Jinv,jac,B] = jacobian_calc(X,Y,1/sqrt(3),-1/sqrt(3));
        elseif i == 3
            [J,Jinv,jac,B] = jacobian_calc(X,Y,1/sqrt(3),1/sqrt(3));
        else
            [J,Jinv,jac,B] = jacobian_calc(X,Y,-1/sqrt(3),1/sqrt(3));
        end
        kloc = kloc + B'*thk*D*B*jac;
    end

end