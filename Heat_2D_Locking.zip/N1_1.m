function N_1 = N1_1(xi,eta)

N_1 = 0.25*(1-xi)*(1-eta);

end
