function N_2 = N2_1(xi,eta)

N_2 = 0.25*(1+xi)*(1-eta);

end