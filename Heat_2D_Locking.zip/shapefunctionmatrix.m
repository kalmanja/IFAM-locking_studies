function N = shapefunctionmatrix(xi,eta)

N = [N1_1(xi,eta) N2_1(xi,eta) N3_1(xi,eta) N4_1(xi,eta)];

end