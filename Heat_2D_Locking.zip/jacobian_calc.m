function [J,Jinv,jac,B] = jacobian_calc(X,Y,xi,eta)
D_N = 0.25*[eta-1 1-eta 1+eta -1-eta; xi-1 -xi-1 xi+1 1-xi];
J = D_N*[X Y];
Jinv = inv(J);
jac = det(J);
B = J\D_N;
end