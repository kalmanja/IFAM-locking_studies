function N_4 = N4_1(xi,eta)

N_4 = 0.25*(1-xi)*(1+eta);

end