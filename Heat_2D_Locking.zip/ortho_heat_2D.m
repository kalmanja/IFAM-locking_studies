clear all
clc
clf


%% Mesh
elem = importdata('elem.txt');
node = importdata('node.txt');
ne = size(elem,1);
nn = size(node,1);
%% Parameters
k_xx = 4.7; k_yy = 5.1;
thk = 1.3;
q_bar = -1000;


ngauss = 4;

%% Stiffness matrix construction
K = zeros(nn,nn);
for i = 1:ne
    X = [node(elem(i,2),2);node(elem(i,3),2);node(elem(i,4),2);node(elem(i,5),2)];
    Y = [node(elem(i,2),3);node(elem(i,3),3);node(elem(i,4),3);node(elem(i,5),3)];    
    kloc = stiffnessmatrix(X,Y,ngauss,thk,k_xx,k_yy);
    nodenum = [node(elem(i,2),1);node(elem(i,3),1);node(elem(i,4),1);node(elem(i,5),1)];
    for j = 1:4
        for k = 1:4
            K(nodenum(j),nodenum(k)) = K(nodenum(j),nodenum(k)) + kloc(j,k);
        end
    end
end


%% Boundary conditions
f_b = zeros(nn,1);
f_b(3) = (1/sqrt(3))* 


